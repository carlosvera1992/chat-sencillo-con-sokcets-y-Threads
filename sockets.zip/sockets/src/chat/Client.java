package chat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    private Socket socket;
    private DataInputStream inputflow;
    private DataOutputStream outputFlow;
    private final Scanner scanner;
    private final String TERMINATION_COMMAND = "chao";

    Client() {
        scanner = new Scanner(System.in);
    }

    
    private void closeConnetion() {//metodo que cierra la conexion
        try {
            socket.close();
            outputFlow.close();
            inputflow.close();
            System.out.println("La conexion ha sido cerrada");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } finally {
            System.exit(0);
        }
    }

    private void executeConnetion() {//Hilo para el cliente

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    openConnetion();
                    openFlows();
                    readData();

                } finally {
                    closeConnetion();
                }
            }
        });
        thread.start();
        try {
            thread.sleep(1000);
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void openConnetion() {//Abre la conexion
        try {
            socket = new Socket("localhost", 4000);
            System.out.println("Conectando...");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void readData() {//lee los datos en el cliente
        String inputData;

        try {
            do {
                inputData = inputflow.readUTF();
                System.out.println("\nServer: " + inputData);
                System.out.println("\nClient: ");
            } while (!inputData.equals(TERMINATION_COMMAND));

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    private void writeData() {//Escribe datos desde el cliente
        String outputData;
        while (true) {
            System.out.println("Client: ");
            outputData = scanner.nextLine();
            if (outputData.length() > 0) {
                send(outputData);
            }
        }

    }

    private void send(String outputData) {//envia los datos desde el cliente al servidor
        try {
            outputFlow.writeUTF(outputData);
            outputFlow.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    private void openFlows() {//abre los Flows

        try {
            outputFlow = new DataOutputStream(socket.getOutputStream());
            inputflow = new DataInputStream(socket.getInputStream());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void main(String[] args) {
        Client client = new Client();
        client.executeConnetion();
        client.writeData();

    }

}

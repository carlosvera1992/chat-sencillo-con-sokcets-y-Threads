package chat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {

    private ServerSocket serverSocket;
    
    private Socket socket;
    private Socket socket2;
    private Socket socket3;
    private Socket socket4;
    private Socket socket5;

    private DataInputStream inputflow;
    private DataOutputStream outputFlow;
    private final Scanner scanner;
    private final String TERMINATION_COMMAND = "chao";

    Server() {
        scanner = new Scanner(System.in);
    }

    private void closeConnetion() {//metodo que cierra la conexion
        try {
            socket.close();
            outputFlow.close();
            inputflow.close();
            System.out.println("La conexion ha sido cerrada");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } finally {
            System.exit(0);
        }
    }

    private void executeConnetion() {//Hilo para el servidor

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    openConnetion();
                    openFlows();
                    readData();

                } finally {
                    closeConnetion();
                }
            }
        });
        thread.start();
        try {
            thread.sleep(1000);
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void openConnetion() {//realiza la conexion entre el servidor y el cliente
        try {
            serverSocket = new ServerSocket(4000);
            System.out.println("Esperando Conexion Entrante...");
            socket = serverSocket.accept();//linea en la que se queda esperando al cliente
            System.out.println("Conexion Establecida");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private void readData() {//lee los datos en el servidor
        String inputData;

        try {
            do {
                inputData = inputflow.readUTF();
                System.out.println("\nClient: " + inputData);
                System.out.println("\nServer: ");
            } while (!inputData.equals(TERMINATION_COMMAND));

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    private void writeData() {//Escribe datos desde el servidor
        String outputData;
        while (true) {
            System.out.println("Server: ");
            outputData = scanner.nextLine();
            if (outputData.length() > 0) {
                send(outputData);
            }
        }

    }

    private void send(String outputData) {//envia los datos desde el servidor al cliente
        try {
            outputFlow.writeUTF(outputData);
            outputFlow.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    private void openFlows() {//abre los flows 

        try {
            outputFlow = new DataOutputStream(socket.getOutputStream());
            inputflow = new DataInputStream(socket.getInputStream());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void main(String[] args) {//metodo principal Main
        Server server = new Server();
        server.executeConnetion();
        server.writeData();
    }
}
